package endpoints;

import java.io.File;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payloads.AuthorModel;

public class EndPoints {
    // Method to create an author
    public static Response createAuthor(AuthorModel payload) {
        // Allowing relaxed HTTPS validation
        RestAssured.useRelaxedHTTPSValidation();
        // Sending POST request to create an author
        Response response = RestAssured.given()
                .header("Content-Type", "application/json", "Accept", ContentType.JSON)
                .baseUri(Routes.BASE_URI)
                .basePath(Routes.POST_BASE_PATH)
                .accept(ContentType.JSON)
                .body(payload)
                .when()
                .post();
        return response;
    }

    // Method to get all authors
    public static Response getAllAuthor() {
        RestAssured.useRelaxedHTTPSValidation();
        // Sending GET request to retrieve all authors
        Response response = RestAssured.given()
                .header("Content-Type", "application/json", "Accept", ContentType.JSON)
                .baseUri(Routes.BASE_URI)
                .basePath(Routes.GET_BASE_PATH)
                .accept(ContentType.JSON)
                .when()
                .get();
        return response;
    }

    // Method to get a single author by ID
    public static Response getSingleAuthor(int id) {
        RestAssured.useRelaxedHTTPSValidation();
        // Sending GET request to retrieve a single author by ID
        Response response = RestAssured.given()
                .header("Content-Type", "application/json", "Accept", ContentType.JSON)
                .baseUri(Routes.BASE_URI)
                .basePath(Routes.GET_BASE_PATH_AUTHOR)
                .pathParam("id", id)
                .accept(ContentType.JSON)
                .when()
                .get();
        return response;
    }

    // Method to get a single author by book ID
    public static Response getSingleAuthorWithBook(int bookid) {
        RestAssured.useRelaxedHTTPSValidation();
        // Sending GET request to retrieve a single author by book ID
        Response response = RestAssured.given()
                .header("Content-Type", "application/json", "Accept", ContentType.JSON)
                .baseUri(Routes.BASE_URI)
                .basePath(Routes.GET_BASE_PATH_BOOK)
                .pathParam("Bookid", bookid)
                .accept(ContentType.JSON)
                .when()
                .get();
        return response;
    }

    // Method to update an author by ID
    public static Response updateAuthor(AuthorModel payload, int id) {
        RestAssured.useRelaxedHTTPSValidation();
        // Sending PUT request to update an author by ID
        Response response = RestAssured.given()
                .header("Content-Type", "application/json", "Accept", ContentType.JSON)
                .baseUri(Routes.BASE_URI)
                .basePath(Routes.GET_BASE_PATH_AUTHOR)
                .pathParam("id", id)
                .accept(ContentType.JSON)
                .body(payload)
                .when()
                .put();
        return response;
    }

    // Method to delete an author by ID
    public static Response deleteAuthor(int id) {
        RestAssured.useRelaxedHTTPSValidation();
        // Sending DELETE request to delete an author by ID
        Response response = RestAssured.given()
                .header("Content-Type", "application/json", "Sever", "Kestrel") // Typo: "Server" instead of "Sever"
                .baseUri(Routes.BASE_URI)
                .basePath(Routes.GET_BASE_PATH_AUTHOR)
                .pathParam("id", id)
                .when()
                .delete();
        return response;
    }

	public static Response createAuthorUsingPayload(File payload) {
		 // Allowing relaxed HTTPS validation
        RestAssured.useRelaxedHTTPSValidation();
        // Sending POST request to create an author
        Response response = RestAssured.given()
                .header("Content-Type", "application/json", "Accept", ContentType.JSON)
                .baseUri(Routes.BASE_URI)
                .basePath(Routes.POST_BASE_PATH)
                .accept(ContentType.JSON)
                .body(payload)
                .when()
                .post();
        return response;
	}
}
