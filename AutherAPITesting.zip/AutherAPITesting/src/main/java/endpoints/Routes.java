package endpoints;

public class Routes {
	// Base URI for the API
	public static String BASE_URI = "https://fakerestapi.azurewebsites.net";

	// Endpoint for getting all authors
	public static String GET_BASE_PATH = "/api/v1/Authors";

	// Endpoint for getting a single author by ID
	public static String GET_BASE_PATH_AUTHOR = "/api/v1/Authors/{id}";

	// Endpoint for getting a single author by book ID
	public static String GET_BASE_PATH_BOOK = "/api/v1/Authors/authors/books/{Bookid}";

	// Endpoint for creating a new author
	public static String POST_BASE_PATH = "/api/v1/Authors";

	// Endpoint for updating an author by ID
	public static String UPDATE_BASE_PATH_AUTHOR = "/api/v1/Authors/{id}";

	// Endpoint for deleting an author by ID
	public static String DELETE_BASE_PATH_AUTHOR = "/api/v1/Authors/{id}";
}
