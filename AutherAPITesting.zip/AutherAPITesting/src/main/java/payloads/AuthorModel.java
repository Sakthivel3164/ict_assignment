package payloads;

public class AuthorModel {

    // Attributes of the AuthorModel class
    public int id;
    public int idbook;
    public String firstName;
    public String lastName;
    
    // Default constructor
    public AuthorModel(){
        
    }
    
    // Parameterized constructor
    public AuthorModel(int id, int idbook, String firstName, String lastName){
        this.id = id;
        this.idbook = idbook;
        this.firstName = firstName;
        this.lastName = lastName;
    }
    
    // Getter for id
    public int getId() {
        return id;
    }
    
    // Getter for idbook
    public int getIdBook() {
        return idbook;
    }
    
    // Getter for firstName
    public String getfirstName() {
        return firstName;
    }
    
    // Getter for lastName
    public String getlastName() {
        return lastName;
    }
    
    // Setter for id
    public void setId(int id) {
        this.id = id;
    }
    
    // Setter for idbook
    public void setIdBook(int idbook) {
        this.idbook = idbook;
    }
    
    // Setter for firstName
    public void setfirstName(String firstName) {
        this.firstName = firstName;
    }
    
    // Setter for lastName
    public void setlastName(String lastName) {
        this.lastName = lastName;
    }
    
    // Override toString method to print the AuthorModel object
    @Override
    public String toString() {
        return "AuthorModel {id='" + id + "', idbook='" + idbook + "', firstName='" + firstName + "', lastName='" + lastName + "'}";
    }
}
