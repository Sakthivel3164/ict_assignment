package testcase;

import static org.testng.Assert.assertEquals;

import java.io.File;

import org.hamcrest.Matchers;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.EndPoints;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import payloads.AuthorModel;
import utilities.DataProviders;
import utilities.ExtentReportManager;

@Listeners(ExtentReportManager.class)	
public class AuthorTest {
    
    private AuthorModel author;
    
    @BeforeClass
    public void setup() {
        // Initialize AuthorModel objects
        author = new AuthorModel();
        // Generate values for author attributes
        author.setId(1);
        author.setIdBook(619);
        author.setfirstName("shebin");
        author.setlastName("P Biju");
    }
    
    // Test method to create an author
    @Test(priority = 0)
    public void testCreateAuthor() {
        Response response = EndPoints.createAuthor(author);
        response.then().log().all();
        assertEquals(response.getStatusCode(), 200);
    }
    
    // Test method to create an author using json payload
    @Test(priority = 1)
	public void postRequest2() {
		File payload = new File(System.getProperty("user.dir") + "/src/main/resources/payload/payload.json");
        Response response = EndPoints.createAuthorUsingPayload(payload);
        response.then().log().all().assertThat().body("firstName", Matchers.equalTo("Shebin"));

        assertEquals(response.getStatusCode(), 200);
	}
    
    // Test method to get all authors
    @Test(priority = 2)
    public void testgetAllAuthor() {
        Response response = EndPoints.getAllAuthor();
        response.then().log().all();
        assertEquals(response.getStatusCode(), 200);
    }
    
    // Test method to get a single author
    @Test(priority = 3)
    public void testgetSingleAuthor() {
        Response response = EndPoints.getSingleAuthor(author.getId());
        AuthorModel auther = response.getBody().as(AuthorModel.class);
        assertEquals(response.getStatusCode(), 200);
        assertEquals(auther.getIdBook(), 1);
        assertEquals(auther.getfirstName(), "First Name 1");
        assertEquals(auther.getlastName(), "Last Name 1");
        
    }
    
    // Test method to get a single author with book
    @Test(priority = 4)
    public void testgetSingleAuthorWithBook() {
        Response response = EndPoints.getSingleAuthorWithBook(author.getIdBook());
        response.then().log().all();
        assertEquals(response.getStatusCode(), 200);
    }
    
    // Test method to update an author
    @Test(priority = 5)
    public void testUpdateAuthor() {
        Response response = EndPoints.updateAuthor(author, author.getId());
        response.then().log().all();
        assertEquals(response.getStatusCode(), 200);
    }
    
    // Test method to delete an author
    @Test(priority = 6)
    public void testDeleteAuthor() {
        Response response = EndPoints.deleteAuthor(author.getId());
        response.then().log().all();
        assertEquals(response.getStatusCode(), 200);
    }
    
    // Test method to create an author using data from Excel
    @Test(priority = 7, dataProvider = "Exceldata", dataProviderClass = DataProviders.class)
    public void testCreateAuthorUsingExcel(String id1, String bookid1, String fname, String lname) {
        int id = Integer.parseInt(id1);
        int bookid = Integer.parseInt(bookid1);
        author = new AuthorModel();
        author.setId(id);
        author.setIdBook(bookid);
        author.setfirstName(fname);
        author.setlastName(lname);
        Response response = EndPoints.createAuthor(author);
        response.then().log().all();
        assertEquals(response.getStatusCode(), 200);
    }
    
    // Test method to validate response schema
    @Test(priority = 8)
    public void testSchemaValidation() {
        // Load JSON schema file
        File f = new File(System.getProperty("user.dir") + "/src/test/resources/Schema.json");
        // Validate schema for first 5 authors
        for (int i = 1; i <= 5; i++) {
            Response response = EndPoints.getSingleAuthor(i);
            response.then().log().all()
                    .assertThat()
                    .body(JsonSchemaValidator.matchesJsonSchema(f));
            System.out.println("--------------- "+i+" schema ------------");
        }
    }
}
