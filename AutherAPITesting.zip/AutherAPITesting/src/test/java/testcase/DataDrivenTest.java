package testcase;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.EndPoints;
import io.restassured.response.Response;
import payloads.AuthorModel;
import utilities.DataProviders;
import utilities.ExtentReportManager; // Importing the ExtentReportManager listener

// Adding the ExtentReportManager listener to this class
@Listeners(ExtentReportManager.class)
public class DataDrivenTest {

    // Test method to create author using data from Excel
    @Test(priority = 1, dataProvider = "Exceldata", dataProviderClass = DataProviders.class)
    public void testCreatingAutherFromExcel(String id, String idBook, String firstName, String lastName) {
        // Creating an instance of AuthorModel with data from Excel
        AuthorModel author = new AuthorModel();
        author.setId(Integer.parseInt(id));
        author.setIdBook(Integer.parseInt(idBook));
        author.setfirstName(firstName);
        author.setlastName(lastName);
        
        // Sending POST request to create author
        Response response = EndPoints.createAuthor(author);
        
        // Logging the response
        response.then().log().all();
        
        // Asserting that the status code is 200
        Assert.assertEquals(response.getStatusCode(), 200);
    }
}
